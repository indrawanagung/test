--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE grabit;
--
-- Name: grabit; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE grabit WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE grabit OWNER TO postgres;

\connect grabit

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id character varying NOT NULL,
    name character varying NOT NULL,
    city_id character varying NOT NULL,
    postal_code integer,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    user_id character varying NOT NULL
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: category_status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.category_status (
    id character varying NOT NULL,
    name character varying
);


ALTER TABLE public.category_status OWNER TO postgres;

--
-- Name: cities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cities (
    id character varying NOT NULL,
    city character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.cities OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id character varying NOT NULL,
    variant_product_id character varying NOT NULL,
    order_id character varying NOT NULL,
    qty integer NOT NULL,
    price bigint NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    address_id character varying NOT NULL,
    total_price bigint NOT NULL,
    created_at character varying NOT NULL,
    deleted_at timestamp without time zone,
    payment_id character varying,
    status_id character varying,
    updated_at character varying,
    description character varying
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payment_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_types (
    id character varying NOT NULL,
    name character varying NOT NULL,
    deleted_at timestamp without time zone
);


ALTER TABLE public.payment_types OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id character varying NOT NULL,
    payment_type_id character varying NOT NULL,
    account_number character varying NOT NULL,
    expiry_date character varying NOT NULL,
    status_id character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: product_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_categories (
    id character varying NOT NULL,
    category_name character varying NOT NULL
);


ALTER TABLE public.product_categories OWNER TO postgres;

--
-- Name: product_stocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_stocks (
    id character varying NOT NULL,
    variation_option_id character varying NOT NULL,
    not_reserved integer NOT NULL,
    reserved integer NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.product_stocks OWNER TO postgres;

--
-- Name: product_volumes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_volumes (
    id character varying NOT NULL,
    variation_option_id character varying NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    length integer NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    weight integer,
    weight_unit_id character varying
);


ALTER TABLE public.product_volumes OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    id character varying NOT NULL,
    name character varying NOT NULL,
    product_category_id character varying NOT NULL,
    status_id character varying NOT NULL,
    price bigint NOT NULL,
    image character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    description text
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version bigint NOT NULL,
    dirty boolean NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: shopping_cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shopping_cart_items (
    id character varying NOT NULL,
    variation_option_id character varying NOT NULL,
    qty integer NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    user_id character varying
);


ALTER TABLE public.shopping_cart_items OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    id character varying NOT NULL,
    category_status_id character varying NOT NULL,
    name character varying,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    color character varying
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    fullname character varying NOT NULL,
    email_address character varying NOT NULL,
    phone_number character varying NOT NULL,
    password character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: variation_options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.variation_options (
    id character varying NOT NULL,
    variation_id character varying NOT NULL,
    option_name character varying NOT NULL,
    description character varying,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone,
    product_id character varying,
    price bigint
);


ALTER TABLE public.variation_options OWNER TO postgres;

--
-- Name: variations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.variations (
    id character varying NOT NULL,
    variation_name character varying NOT NULL,
    created_at character varying NOT NULL,
    updated_at character varying,
    deleted_at timestamp without time zone
);


ALTER TABLE public.variations OWNER TO postgres;

--
-- Name: weight_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weight_units (
    id character varying NOT NULL,
    unit_name character varying NOT NULL
);


ALTER TABLE public.weight_units OWNER TO postgres;

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, name, city_id, postal_code, created_at, updated_at, deleted_at, user_id) FROM stdin;
\.
COPY public.address (id, name, city_id, postal_code, created_at, updated_at, deleted_at, user_id) FROM '$$PATH$$/4951.dat';

--
-- Data for Name: category_status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.category_status (id, name) FROM stdin;
\.
COPY public.category_status (id, name) FROM '$$PATH$$/4952.dat';

--
-- Data for Name: cities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cities (id, city, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.cities (id, city, created_at, updated_at, deleted_at) FROM '$$PATH$$/4953.dat';

--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, variant_product_id, order_id, qty, price) FROM stdin;
\.
COPY public.order_items (id, variant_product_id, order_id, qty, price) FROM '$$PATH$$/4954.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, user_id, address_id, total_price, created_at, deleted_at, payment_id, status_id, updated_at, description) FROM stdin;
\.
COPY public.orders (id, user_id, address_id, total_price, created_at, deleted_at, payment_id, status_id, updated_at, description) FROM '$$PATH$$/4955.dat';

--
-- Data for Name: payment_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_types (id, name, deleted_at) FROM stdin;
\.
COPY public.payment_types (id, name, deleted_at) FROM '$$PATH$$/4956.dat';

--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, payment_type_id, account_number, expiry_date, status_id, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.payments (id, payment_type_id, account_number, expiry_date, status_id, created_at, updated_at, deleted_at) FROM '$$PATH$$/4957.dat';

--
-- Data for Name: product_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_categories (id, category_name) FROM stdin;
\.
COPY public.product_categories (id, category_name) FROM '$$PATH$$/4958.dat';

--
-- Data for Name: product_stocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_stocks (id, variation_option_id, not_reserved, reserved, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.product_stocks (id, variation_option_id, not_reserved, reserved, created_at, updated_at, deleted_at) FROM '$$PATH$$/4959.dat';

--
-- Data for Name: product_volumes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_volumes (id, variation_option_id, width, height, length, created_at, updated_at, deleted_at, weight, weight_unit_id) FROM stdin;
\.
COPY public.product_volumes (id, variation_option_id, width, height, length, created_at, updated_at, deleted_at, weight, weight_unit_id) FROM '$$PATH$$/4960.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (id, name, product_category_id, status_id, price, image, created_at, updated_at, deleted_at, description) FROM stdin;
\.
COPY public.products (id, name, product_category_id, status_id, price, image, created_at, updated_at, deleted_at, description) FROM '$$PATH$$/4961.dat';

--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version, dirty) FROM stdin;
\.
COPY public.schema_migrations (version, dirty) FROM '$$PATH$$/4962.dat';

--
-- Data for Name: shopping_cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shopping_cart_items (id, variation_option_id, qty, created_at, updated_at, deleted_at, user_id) FROM stdin;
\.
COPY public.shopping_cart_items (id, variation_option_id, qty, created_at, updated_at, deleted_at, user_id) FROM '$$PATH$$/4963.dat';

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (id, category_status_id, name, created_at, updated_at, deleted_at, color) FROM stdin;
\.
COPY public.status (id, category_status_id, name, created_at, updated_at, deleted_at, color) FROM '$$PATH$$/4964.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, fullname, email_address, phone_number, password, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.users (id, fullname, email_address, phone_number, password, created_at, updated_at, deleted_at) FROM '$$PATH$$/4965.dat';

--
-- Data for Name: variation_options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.variation_options (id, variation_id, option_name, description, created_at, updated_at, deleted_at, product_id, price) FROM stdin;
\.
COPY public.variation_options (id, variation_id, option_name, description, created_at, updated_at, deleted_at, product_id, price) FROM '$$PATH$$/4966.dat';

--
-- Data for Name: variations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.variations (id, variation_name, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.variations (id, variation_name, created_at, updated_at, deleted_at) FROM '$$PATH$$/4967.dat';

--
-- Data for Name: weight_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weight_units (id, unit_name) FROM stdin;
\.
COPY public.weight_units (id, unit_name) FROM '$$PATH$$/4968.dat';

--
-- Name: address address_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pk PRIMARY KEY (id);


--
-- Name: category_status category_status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.category_status
    ADD CONSTRAINT category_status_pk PRIMARY KEY (id);


--
-- Name: cities cities_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cities
    ADD CONSTRAINT cities_pk PRIMARY KEY (id);


--
-- Name: payments paymentmethods_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT paymentmethods_pk PRIMARY KEY (id);


--
-- Name: payment_types paymenttypes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_types
    ADD CONSTRAINT paymenttypes_pk PRIMARY KEY (id);


--
-- Name: product_categories product_category_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_categories
    ADD CONSTRAINT product_category_pk PRIMARY KEY (id);


--
-- Name: product_volumes product_volumes_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_volumes
    ADD CONSTRAINT product_volumes_pk PRIMARY KEY (id);


--
-- Name: products products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pk PRIMARY KEY (id);


--
-- Name: product_stocks productstocks_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT productstocks_pk PRIMARY KEY (id);


--
-- Name: weight_units productweight_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weight_units
    ADD CONSTRAINT productweight_pk PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: order_items shoporderitems_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT shoporderitems_pk PRIMARY KEY (id);


--
-- Name: orders shoporders_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT shoporders_pk PRIMARY KEY (id);


--
-- Name: shopping_cart_items shoppingcartitems_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items
    ADD CONSTRAINT shoppingcartitems_pk PRIMARY KEY (id);


--
-- Name: status status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pk PRIMARY KEY (id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (id);


--
-- Name: variation_options variationoptions_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variation_options
    ADD CONSTRAINT variationoptions_pk PRIMARY KEY (id);


--
-- Name: variations variations_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variations
    ADD CONSTRAINT variations_pk PRIMARY KEY (id);


--
-- Name: address address_city_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_city_fk FOREIGN KEY (city_id) REFERENCES public.cities(id);


--
-- Name: address address_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_users_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: payments paymenmethods_paymenttypes_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT paymenmethods_paymenttypes_fk FOREIGN KEY (payment_type_id) REFERENCES public.payment_types(id);


--
-- Name: payments paymenmethods_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT paymenmethods_status_fk FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: product_stocks product_stocks_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_stocks
    ADD CONSTRAINT product_stocks_fk FOREIGN KEY (variation_option_id) REFERENCES public.variation_options(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_volumes product_volumes_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_volumes
    ADD CONSTRAINT product_volumes_fk FOREIGN KEY (weight_unit_id) REFERENCES public.weight_units(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: product_volumes product_volumes_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_volumes
    ADD CONSTRAINT product_volumes_fk2 FOREIGN KEY (variation_option_id) REFERENCES public.variation_options(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: products products_productcategory_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_productcategory_fk FOREIGN KEY (product_category_id) REFERENCES public.product_categories(id);


--
-- Name: products products_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_status_fk FOREIGN KEY (status_id) REFERENCES public.status(id);


--
-- Name: order_items shoporderitems_products_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT shoporderitems_products_fk FOREIGN KEY (variant_product_id) REFERENCES public.variation_options(id);


--
-- Name: order_items shoporderitems_shoporders_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT shoporderitems_shoporders_fk FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: orders shoporders_address_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT shoporders_address_fk FOREIGN KEY (address_id) REFERENCES public.address(id);


--
-- Name: orders shoporders_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT shoporders_users_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shopping_cart_items shopping_cart_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shopping_cart_items
    ADD CONSTRAINT shopping_cart_items_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: status status_category_status_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_category_status_fk FOREIGN KEY (category_status_id) REFERENCES public.category_status(id);


--
-- Name: variation_options variation_options_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variation_options
    ADD CONSTRAINT variation_options_fk FOREIGN KEY (product_id) REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: variation_options variationoptions_variation_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.variation_options
    ADD CONSTRAINT variationoptions_variation_fk FOREIGN KEY (variation_id) REFERENCES public.variations(id);


--
-- PostgreSQL database dump complete
--

